﻿namespace Lab_2_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.widthLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.areaLabel = new System.Windows.Forms.Label();
            this.carpetChargeLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.laborChargeLabel = new System.Windows.Forms.Label();
            this.orderTotalLabel = new System.Windows.Forms.Label();
            this.areaLblLabel = new System.Windows.Forms.Label();
            this.carpetChargeLblLabel = new System.Windows.Forms.Label();
            this.taxLblLabel = new System.Windows.Forms.Label();
            this.laborChargeLblLabel = new System.Windows.Forms.Label();
            this.orderTotalLblLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.BackColor = System.Drawing.Color.White;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(75, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(261, 40);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Carpet Calculator";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lengthLabel
            // 
            this.lengthLabel.Location = new System.Drawing.Point(23, 61);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(115, 57);
            this.lengthLabel.TabIndex = 1;
            this.lengthLabel.Text = "Carpet Length (feet):";
            this.lengthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(27, 123);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(100, 26);
            this.lengthTextBox.TabIndex = 2;
            this.lengthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(148, 123);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(100, 26);
            this.widthTextBox.TabIndex = 4;
            this.widthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(267, 123);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(100, 26);
            this.priceTextBox.TabIndex = 6;
            this.priceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // widthLabel
            // 
            this.widthLabel.Location = new System.Drawing.Point(144, 52);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(111, 62);
            this.widthLabel.TabIndex = 3;
            this.widthLabel.Text = "Carpet Width (feet):";
            this.widthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // priceLabel
            // 
            this.priceLabel.Location = new System.Drawing.Point(266, 61);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(101, 44);
            this.priceLabel.TabIndex = 5;
            this.priceLabel.Text = "Carpet Price ( $ / sq. ft.)";
            this.priceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // areaLabel
            // 
            this.areaLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.areaLabel.Location = new System.Drawing.Point(229, 161);
            this.areaLabel.Name = "areaLabel";
            this.areaLabel.Size = new System.Drawing.Size(138, 34);
            this.areaLabel.TabIndex = 9;
            this.areaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // carpetChargeLabel
            // 
            this.carpetChargeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carpetChargeLabel.Location = new System.Drawing.Point(229, 210);
            this.carpetChargeLabel.Name = "carpetChargeLabel";
            this.carpetChargeLabel.Size = new System.Drawing.Size(138, 33);
            this.carpetChargeLabel.TabIndex = 11;
            this.carpetChargeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxLabel.Location = new System.Drawing.Point(229, 254);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(138, 30);
            this.taxLabel.TabIndex = 13;
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // laborChargeLabel
            // 
            this.laborChargeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborChargeLabel.Location = new System.Drawing.Point(229, 296);
            this.laborChargeLabel.Name = "laborChargeLabel";
            this.laborChargeLabel.Size = new System.Drawing.Size(138, 29);
            this.laborChargeLabel.TabIndex = 15;
            this.laborChargeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderTotalLabel
            // 
            this.orderTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderTotalLabel.Location = new System.Drawing.Point(229, 351);
            this.orderTotalLabel.Name = "orderTotalLabel";
            this.orderTotalLabel.Size = new System.Drawing.Size(138, 34);
            this.orderTotalLabel.TabIndex = 18;
            this.orderTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // areaLblLabel
            // 
            this.areaLblLabel.AutoSize = true;
            this.areaLblLabel.Location = new System.Drawing.Point(71, 161);
            this.areaLblLabel.Name = "areaLblLabel";
            this.areaLblLabel.Size = new System.Drawing.Size(152, 20);
            this.areaLblLabel.TabIndex = 8;
            this.areaLblLabel.Text = "Carpet Area (sq. ft.):";
            // 
            // carpetChargeLblLabel
            // 
            this.carpetChargeLblLabel.AutoSize = true;
            this.carpetChargeLblLabel.Location = new System.Drawing.Point(106, 216);
            this.carpetChargeLblLabel.Name = "carpetChargeLblLabel";
            this.carpetChargeLblLabel.Size = new System.Drawing.Size(117, 20);
            this.carpetChargeLblLabel.TabIndex = 10;
            this.carpetChargeLblLabel.Text = "Carpet Charge:";
            // 
            // taxLblLabel
            // 
            this.taxLblLabel.AutoSize = true;
            this.taxLblLabel.Location = new System.Drawing.Point(17, 259);
            this.taxLblLabel.Name = "taxLblLabel";
            this.taxLblLabel.Size = new System.Drawing.Size(206, 20);
            this.taxLblLabel.TabIndex = 12;
            this.taxLblLabel.Text = "Sales Tax (7.0%) on Carpet:";
            // 
            // laborChargeLblLabel
            // 
            this.laborChargeLblLabel.AutoSize = true;
            this.laborChargeLblLabel.Location = new System.Drawing.Point(8, 305);
            this.laborChargeLblLabel.Name = "laborChargeLblLabel";
            this.laborChargeLblLabel.Size = new System.Drawing.Size(215, 20);
            this.laborChargeLblLabel.TabIndex = 14;
            this.laborChargeLblLabel.Text = "Labor Charge ($0.50 / sq. ft.):";
            // 
            // orderTotalLblLabel
            // 
            this.orderTotalLblLabel.AutoSize = true;
            this.orderTotalLblLabel.Location = new System.Drawing.Point(97, 358);
            this.orderTotalLblLabel.Name = "orderTotalLblLabel";
            this.orderTotalLblLabel.Size = new System.Drawing.Size(126, 20);
            this.orderTotalLblLabel.TabIndex = 17;
            this.orderTotalLblLabel.Text = "ORDER TOTAL:";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(24, 155);
            this.groupBox1.MaximumSize = new System.Drawing.Size(370, 3);
            this.groupBox1.MinimumSize = new System.Drawing.Size(370, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(370, 3);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(12, 404);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 40);
            this.calculateButton.TabIndex = 20;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(267, 409);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(113, 35);
            this.exitButton.TabIndex = 22;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(135, 409);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(113, 35);
            this.clearButton.TabIndex = 21;
            this.clearButton.Text = "Clea&r";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(21, 395);
            this.groupBox2.MaximumSize = new System.Drawing.Size(370, 3);
            this.groupBox2.MinimumSize = new System.Drawing.Size(370, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(370, 3);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(237, 338);
            this.groupBox3.MaximumSize = new System.Drawing.Size(125, 3);
            this.groupBox3.MinimumSize = new System.Drawing.Size(125, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(125, 3);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 465);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.orderTotalLblLabel);
            this.Controls.Add(this.laborChargeLblLabel);
            this.Controls.Add(this.taxLblLabel);
            this.Controls.Add(this.carpetChargeLblLabel);
            this.Controls.Add(this.areaLblLabel);
            this.Controls.Add(this.orderTotalLabel);
            this.Controls.Add(this.laborChargeLabel);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.carpetChargeLabel);
            this.Controls.Add(this.areaLabel);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.widthLabel);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(this.widthTextBox);
            this.Controls.Add(this.lengthTextBox);
            this.Controls.Add(this.lengthLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carpet Kingdom";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label areaLabel;
        private System.Windows.Forms.Label carpetChargeLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label laborChargeLabel;
        private System.Windows.Forms.Label orderTotalLabel;
        private System.Windows.Forms.Label areaLblLabel;
        private System.Windows.Forms.Label carpetChargeLblLabel;
        private System.Windows.Forms.Label taxLblLabel;
        private System.Windows.Forms.Label laborChargeLblLabel;
        private System.Windows.Forms.Label orderTotalLblLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

